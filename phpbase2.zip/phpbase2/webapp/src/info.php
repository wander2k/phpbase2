<?PHP
phpinfo();