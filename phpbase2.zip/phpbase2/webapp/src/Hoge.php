<?php

namespace UnitTest¥Sample {
  protected $settings = null;

  public function __construct (
     $settings
   ) {
     $this->settings = $settings;
   }
}
